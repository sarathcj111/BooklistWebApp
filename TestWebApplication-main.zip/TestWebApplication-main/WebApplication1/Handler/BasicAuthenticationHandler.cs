﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Handler
{
    public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        private readonly IConfiguration _config;      
        public BasicAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock,
            IConfiguration config)
            : base(options, logger, encoder, clock)
        {
            _config = config;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            if (!Request.Headers.ContainsKey("Authorization"))
                return AuthenticateResult.Fail("Authorization header not found");

            //var authenticationHeaderValue = AuthenticationHeaderValue.Parse(Request.Headers["Authorization"]);
            //return AuthenticateResult.Fail("Need to implement");
            var authList = GenerateAuthList();
            return AuthenticateResult.Success(JsonConvert.SerializeObject(authList));

        }

        private List<AuthModel> GenerateAuthList()
        {
            var authList = new List<AuthModel>();
            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"User{i + 1}:Id") > 0)
                {
                    AuthModel user = new AuthModel();
                    //user.Id = _config.GetValue<int>($"Book{i + 1}:Id");
                    user.UserName = _config.GetValue<string>($"User{i + 1}:UserName");
                    user.Password = _config.GetValue<string>($"User{i + 1}:Password");
                    authList.Add(user);
                }
                else
                    break;
            }
            return authList;
        }
    }
}
